from datetime import datetime
import json
import os

import boto3

# Update this to match the name of your Tracker resource
TRACKER_NAME = "trackedAsset01"



def dt_parser(dt):
    if isinstance(dt, datetime):
        return dt.isoformat()

def lambda_handler(event, context):
  # load the side-loaded Amazon Location service model; needed during Public Preview
  os.environ["AWS_DATA_PATH"] = os.environ["LAMBDA_TASK_ROOT"]

  updates = [
    {
      "DeviceId": event["payload"]["deviceid"],
      "SampleTime": datetime.fromtimestamp(event["payload"]
["timestamp"]).isoformat(),
      "Position": [
        event["payload"]["location"]["long"],
        event["payload"]["location"]["lat"]
      ]
    }
  ]

  print(updates);
  client = boto3.client("location")
  response = client.batch_update_device_position(TrackerName=TRACKER_NAME, Updates=updates)
  print(response);
  
  return {
    "statusCode": 200,
    "body": json.dumps(response, default=dt_parser)
  }
